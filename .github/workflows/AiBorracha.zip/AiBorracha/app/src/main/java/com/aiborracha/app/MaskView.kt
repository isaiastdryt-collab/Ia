package com.aiborracha.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.view.MotionEvent
import android.view.View

/** Mostra a imagem e deixa o usuário marcar (pincel), desmarcar (borracha) ou contornar (circular) o que será apagado. */
class MaskView(ctx: Context) : View(ctx) {

    enum class Tool { BRUSH, ERASER, LASSO }

    var tool = Tool.BRUSH
    var brushSize = 36f * resources.displayMetrics.density // px na tela

    private var image: Bitmap? = null
    private var mask: Bitmap? = null
    private var maskCanvas: Canvas? = null

    private val imgMatrix = Matrix()
    private val invMatrix = Matrix()
    private val values = FloatArray(9)

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val maskDrawPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 150 }
    private val red = 0xFFFF1744.toInt()
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = red
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = red
    }
    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val path = Path()
    private var lastX = 0f
    private var lastY = 0f

    fun setImage(bmp: Bitmap) {
        image = bmp
        val m = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        mask = m
        maskCanvas = Canvas(m)
        computeMatrix()
        invalidate()
    }

    fun getImage(): Bitmap? = image

    fun getMask(): BooleanArray? {
        val m = mask ?: return null
        val w = m.width
        val h = m.height
        val px = IntArray(w * h)
        m.getPixels(px, 0, w, 0, 0, w, h)
        return BooleanArray(w * h) { (px[it] ushr 24) > 40 }
    }

    fun clearMask() {
        mask?.eraseColor(0)
        invalidate()
    }

    private fun computeMatrix() {
        val img = image ?: return
        if (width == 0 || height == 0) return
        val s = minOf(width.toFloat() / img.width, height.toFloat() / img.height)
        val dx = (width - img.width * s) / 2f
        val dy = (height - img.height * s) / 2f
        imgMatrix.reset()
        imgMatrix.postScale(s, s)
        imgMatrix.postTranslate(dx, dy)
        imgMatrix.invert(invMatrix)
    }

    private fun scale(): Float {
        imgMatrix.getValues(values)
        return values[Matrix.MSCALE_X]
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeMatrix()
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF222222.toInt())
        val img = image ?: return
        c.save()
        c.concat(imgMatrix)
        c.drawBitmap(img, 0f, 0f, bitmapPaint)
        mask?.let { c.drawBitmap(it, 0f, 0f, maskDrawPaint) }
        if (tool == Tool.LASSO && !path.isEmpty) {
            previewPaint.strokeWidth = 3f / scale()
            c.drawPath(path, previewPaint)
        }
        c.restore()
    }

    private fun stroke(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        strokePaint.strokeWidth = brushSize / scale()
        strokePaint.xfermode = if (tool == Tool.ERASER) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        if (x1 == x2 && y1 == y2) c.drawPoint(x1, y1, strokePaint) else c.drawLine(x1, y1, x2, y2, strokePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (image == null) return false
        val mc = maskCanvas ?: return false
        val p = floatArrayOf(e.x, e.y)
        invMatrix.mapPoints(p)
        val x = p[0]
        val y = p[1]
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                path.reset()
                path.moveTo(x, y)
                lastX = x
                lastY = y
                if (tool != Tool.LASSO) stroke(mc, x, y, x, y)
            }
            MotionEvent.ACTION_MOVE -> {
                path.lineTo(x, y)
                if (tool != Tool.LASSO) stroke(mc, lastX, lastY, x, y)
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (tool == Tool.LASSO) {
                    path.close()
                    mc.drawPath(path, fillPaint)
                }
                path.reset()
            }
        }
        invalidate()
        return true
    }
}
