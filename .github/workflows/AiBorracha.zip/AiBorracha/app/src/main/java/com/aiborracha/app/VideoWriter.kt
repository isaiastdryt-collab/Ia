package com.aiborracha.app

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface

/** Grava os quadros processados em um MP4 (H.264, sem áudio). */
class VideoWriter(path: String, w: Int, h: Int, private val fps: Int) {
    private val encoder: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
    private val muxer = MediaMuxer(path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val surface: Surface
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false
    private var count = 0L

    init {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 6_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        surface = encoder.createInputSurface()
        encoder.start()
    }

    fun write(bmp: Bitmap) {
        val c = surface.lockCanvas(null)
        c.drawBitmap(bmp, 0f, 0f, null)
        surface.unlockCanvasAndPost(c)
        drain(false)
    }

    fun finish() {
        encoder.signalEndOfInputStream()
        drain(true)
        encoder.stop()
        encoder.release()
        if (started) muxer.stop()
        muxer.release()
        surface.release()
    }

    private fun drain(end: Boolean) {
        while (true) {
            val idx = encoder.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end) return
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(encoder.outputFormat)
                muxer.start()
                started = true
            } else if (idx >= 0) {
                val buf = encoder.getOutputBuffer(idx)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started) {
                    info.presentationTimeUs = count * 1_000_000L / fps
                    count++
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(track, buf, info)
                }
                encoder.releaseOutputBuffer(idx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }
    }
}
