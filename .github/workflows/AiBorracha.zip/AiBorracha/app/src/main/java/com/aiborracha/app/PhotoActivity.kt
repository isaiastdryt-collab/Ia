package com.aiborracha.app

import android.graphics.Bitmap
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class PhotoActivity : AppCompatActivity() {

    private lateinit var mv: MaskView
    private lateinit var btnErase: MaterialButton
    private val history = ArrayList<Bitmap>()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uri = intent.data
        val bmp = if (uri != null) decodeBitmap(this, uri, 2048) else null
        if (bmp == null) {
            toast("Não consegui abrir a foto")
            finish()
            return
        }

        mv = MaskView(this)
        mv.setImage(bmp)

        val undo = actionButton("Desfazer") { undo() }
        btnErase = actionButton("Apagar") { erase() }
        val save = actionButton("Salvar") {
            val img = mv.getImage()
            if (img != null && saveImage(this, img)) toast("Salvo em Imagens/AiBorracha") else toast("Erro ao salvar")
        }
        setContentView(editorLayout(mv, listOf(undo, btnErase, save)))
    }

    private fun undo() {
        if (busy || history.isEmpty()) return
        mv.setImage(history.removeAt(history.size - 1))
    }

    private fun erase() {
        if (busy) return
        val mask = mv.getMask()
        val img = mv.getImage()
        if (mask == null || img == null || mask.none { it }) {
            toast("Marque o que quer apagar")
            return
        }
        busy = true
        btnErase.isEnabled = false
        btnErase.text = "Apagando..."
        Thread {
            val out = try { Inpainter.inpaint(img, mask) } catch (e: Throwable) { null }
            runOnUiThread {
                if (out != null) {
                    history.add(img)
                    if (history.size > 5) history.removeAt(0)
                    mv.setImage(out)
                } else {
                    toast("Erro ao apagar")
                }
                btnErase.text = "Apagar"
                btnErase.isEnabled = true
                busy = false
            }
        }.start()
    }
}
