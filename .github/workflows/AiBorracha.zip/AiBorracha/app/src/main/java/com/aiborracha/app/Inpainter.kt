package com.aiborracha.app

import android.graphics.Bitmap
import kotlin.random.Random

/**
 * Preenchimento simples (sem IA): propaga as cores do entorno para dentro da área marcada
 * e suaviza. Funciona bem em objetos pequenos e fundos lisos.
 */
object Inpainter {

    /** Aumenta a máscara em [r] pixels para cobrir as bordas do pincel. */
    fun grow(mask: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        var cur = mask
        repeat(r) {
            val next = cur.copyOf()
            for (y in 0 until h) for (x in 0 until w) {
                val i = y * w + x
                if (cur[i]) {
                    if (x > 0) next[i - 1] = true
                    if (x < w - 1) next[i + 1] = true
                    if (y > 0) next[i - w] = true
                    if (y < h - 1) next[i + w] = true
                }
            }
            cur = next
        }
        return cur
    }

    fun inpaint(src: Bitmap, mask: BooleanArray): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        fill(px, grow(mask, w, h, 3), w, h)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private class IntList {
        var a = IntArray(1024)
        var n = 0
        fun add(v: Int) {
            if (n == a.size) a = a.copyOf(n * 2)
            a[n++] = v
        }
    }

    private fun avgKnown(px: IntArray, known: BooleanArray, w: Int, h: Int, p: Int): Int {
        val x = p % w
        val y = p / w
        var r = 0; var g = 0; var b = 0; var c = 0
        for (dy in -1..1) for (dx in -1..1) {
            if (dx == 0 && dy == 0) continue
            val nx = x + dx
            val ny = y + dy
            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
            val q = ny * w + nx
            if (!known[q]) continue
            val col = px[q]
            r += (col shr 16) and 0xFF
            g += (col shr 8) and 0xFF
            b += col and 0xFF
            c++
        }
        if (c == 0) return 0
        return (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
    }

    /** Preenche in-place os pixels onde mask == true. */
    fun fill(px: IntArray, mask: BooleanArray, w: Int, h: Int) {
        val n = w * h
        val known = BooleanArray(n) { !mask[it] }
        val queued = BooleanArray(n)
        val all = IntList()
        for (i in 0 until n) if (mask[i]) all.add(i)
        if (all.n == 0) return

        var frontier = IntList()
        for (k in 0 until all.n) {
            val p = all.a[k]
            if (avgKnown(px, known, w, h, p) != 0) {
                frontier.add(p)
                queued[p] = true
            }
        }
        if (frontier.n == 0) {
            for (k in 0 until all.n) px[all.a[k]] = 0xFF808080.toInt()
            return
        }

        // 1) descasca a área de fora para dentro
        while (frontier.n > 0) {
            val cols = IntArray(frontier.n)
            for (k in 0 until frontier.n) cols[k] = avgKnown(px, known, w, h, frontier.a[k])
            for (k in 0 until frontier.n) {
                px[frontier.a[k]] = cols[k]
                known[frontier.a[k]] = true
            }
            val next = IntList()
            for (k in 0 until frontier.n) {
                val p = frontier.a[k]
                val x = p % w
                val y = p / w
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (mask[q] && !known[q] && !queued[q]) {
                        queued[q] = true
                        next.add(q)
                    }
                }
            }
            frontier = next
        }

        // 2) suaviza
        val iters = if (all.n > 300_000) 25 else 60
        repeat(iters) {
            for (k in 0 until all.n) {
                val p = all.a[k]
                val x = p % w
                val y = p / w
                var r = 0; var g = 0; var b = 0; var c = 0
                if (x > 0) { val col = px[p - 1]; r += (col shr 16) and 0xFF; g += (col shr 8) and 0xFF; b += col and 0xFF; c++ }
                if (x < w - 1) { val col = px[p + 1]; r += (col shr 16) and 0xFF; g += (col shr 8) and 0xFF; b += col and 0xFF; c++ }
                if (y > 0) { val col = px[p - w]; r += (col shr 16) and 0xFF; g += (col shr 8) and 0xFF; b += col and 0xFF; c++ }
                if (y < h - 1) { val col = px[p + w]; r += (col shr 16) and 0xFF; g += (col shr 8) and 0xFF; b += col and 0xFF; c++ }
                if (c > 0) px[p] = (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
            }
        }

        // 3) ruído leve para não ficar "chapado"
        val rnd = Random(1)
        for (k in 0 until all.n) {
            val p = all.a[k]
            val col = px[p]
            val d = rnd.nextInt(-4, 5)
            val r = (((col shr 16) and 0xFF) + d).coerceIn(0, 255)
            val g = (((col shr 8) and 0xFF) + d).coerceIn(0, 255)
            val b = ((col and 0xFF) + d).coerceIn(0, 255)
            px[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
}
