package com.aiborracha.app

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import java.io.File

val RED: Int = Color.parseColor("#D32F2F")

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

fun Context.actionButton(label: String, onClick: () -> Unit): MaterialButton =
    MaterialButton(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

fun decodeBitmap(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    ImageDecoder.decodeBitmap(src) { dec, info, _ ->
        val big = maxOf(info.size.width, info.size.height)
        if (big > maxSide) {
            val f = maxSide.toFloat() / big
            dec.setTargetSize(
                (info.size.width * f).toInt().coerceAtLeast(1),
                (info.size.height * f).toInt().coerceAtLeast(1)
            )
        }
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        dec.isMutableRequired = true
    }
} catch (e: Exception) {
    null
}

fun saveImage(ctx: Context, bmp: Bitmap): Boolean = try {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "AiBorracha_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AiBorracha")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    if (uri == null) false else {
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        true
    }
} catch (e: Exception) {
    false
}

fun saveVideo(ctx: Context, file: File): Boolean = try {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "AiBorracha_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AiBorracha")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
    if (uri == null) false else {
        ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        true
    }
} catch (e: Exception) {
    false
}

/** Tela de edição compartilhada por foto e vídeo: imagem + pincel/borracha/circular + tamanho + ações. */
fun Activity.editorLayout(mv: MaskView, actions: List<View>): View {
    val root = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(0xFF222222.toInt())
    }
    root.addView(mv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

    mv.brushSize = (6 + 30) * resources.displayMetrics.density
    val seek = SeekBar(this).apply {
        max = 100
        progress = 30
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                mv.brushSize = (6 + p) * resources.displayMetrics.density
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }
    root.addView(seek, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
        setMargins(dp(16), dp(4), dp(16), 0)
    })

    val tools = listOf(
        "Pincel" to MaskView.Tool.BRUSH,
        "Borracha" to MaskView.Tool.ERASER,
        "Circular" to MaskView.Tool.LASSO
    )
    val toolButtons = ArrayList<MaterialButton>()
    fun refresh() {
        toolButtons.forEachIndexed { i, b ->
            val sel = tools[i].second == mv.tool
            b.backgroundTintList = ColorStateList.valueOf(if (sel) RED else 0xFF555555.toInt())
        }
    }
    val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    tools.forEach { (name, tool) ->
        val b = actionButton(name) { mv.tool = tool; refresh() }
        toolButtons.add(b)
        row1.addView(b, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
    }
    refresh()
    root.addView(row1, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(8), dp(4), dp(8), 0) })

    val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    actions.forEach {
        row2.addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
    }
    root.addView(row2, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(8), 0, dp(8), dp(8)) })
    return root
}
