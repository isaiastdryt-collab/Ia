package com.aiborracha.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.io.File

class VideoActivity : AppCompatActivity() {

    private lateinit var mv: MaskView
    private lateinit var btnErase: MaterialButton
    private val retriever = MediaMetadataRetriever()
    private var w = 0
    private var h = 0
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        var first: Bitmap? = null
        try {
            retriever.setDataSource(this, intent.data!!)
            first = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
        }
        if (first == null) {
            toast("Não consegui abrir o vídeo")
            finish()
            return
        }

        // processa em no máximo 720 px de lado maior (mais rápido)
        val sc = minOf(1f, 720f / maxOf(first.width, first.height))
        w = ((first.width * sc).toInt() and 1.inv()).coerceAtLeast(2)
        h = ((first.height * sc).toInt() and 1.inv()).coerceAtLeast(2)

        mv = MaskView(this)
        mv.setImage(Bitmap.createScaledBitmap(first, w, h, true))

        btnErase = actionButton("Apagar no vídeo (quadro a quadro)") { process() }
        setContentView(editorLayout(mv, listOf(btnErase)))
    }

    private fun process() {
        if (busy) return
        val rawMask = mv.getMask()
        if (rawMask == null || rawMask.none { it }) {
            toast("Marque o que quer apagar")
            return
        }
        busy = true
        btnErase.isEnabled = false
        val mask = Inpainter.grow(rawMask, w, h, 3)

        Thread {
            var ok = false
            val tmp = File(cacheDir, "saida.mp4")
            try {
                val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
                val fps = 30
                val total = (durMs * fps / 1000).toInt().coerceAtLeast(1)
                val writer = VideoWriter(tmp.absolutePath, w, h, fps)
                val work = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(work)
                val dst = Rect(0, 0, w, h)
                val px = IntArray(w * h)

                for (i in 0 until total) {
                    val frame = retriever.getFrameAtTime(i * 1_000_000L / fps, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (frame != null) {
                        canvas.drawBitmap(frame, null, dst, null)
                        work.getPixels(px, 0, w, 0, 0, w, h)
                        Inpainter.fill(px, mask, w, h)
                        work.setPixels(px, 0, w, 0, 0, w, h)
                    }
                    writer.write(work)
                    if (i % 5 == 0) runOnUiThread { btnErase.text = "Processando ${i * 100 / total}%" }
                }
                writer.finish()
                ok = saveVideo(this, tmp)
            } catch (e: Throwable) {
                ok = false
            }
            runOnUiThread {
                btnErase.text = "Apagar no vídeo (quadro a quadro)"
                btnErase.isEnabled = true
                busy = false
                toast(if (ok) "Vídeo salvo em Filmes/AiBorracha (sem áudio)" else "Erro ao processar o vídeo")
            }
        }.start()
    }
}
