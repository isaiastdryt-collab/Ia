package com.aiborracha.app

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) open(uri, false)
    }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) open(uri, true)
    }
    private val pickAny = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) open(uri, (contentResolver.getType(uri) ?: "").startsWith("video"))
    }

    private fun open(uri: Uri, video: Boolean) {
        val i = Intent(this, if (video) VideoActivity::class.java else PhotoActivity::class.java)
        i.data = uri
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(i)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(RED)
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }

        val title = TextView(this).apply {
            text = "Ai borracha"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 40f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Apague pessoas e objetos das suas fotos e vídeos"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(sub, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(48) })

        fun homeButton(label: String, onClick: () -> Unit) {
            val b = MaterialButton(this).apply {
                text = label
                setTextColor(RED)
                textSize = 18f
                backgroundTintList = ColorStateList.valueOf(Color.WHITE)
                setOnClickListener { onClick() }
            }
            root.addView(b, LinearLayout.LayoutParams(MATCH_PARENT, dp(60)).apply { topMargin = dp(12) })
        }

        homeButton("Foto") { pickPhoto.launch(arrayOf("image/*")) }
        homeButton("Vídeo") { pickVideo.launch(arrayOf("video/*")) }
        homeButton("Escolher foto ou vídeo") { pickAny.launch(arrayOf("image/*", "video/*")) }

        setContentView(root)
    }
}
